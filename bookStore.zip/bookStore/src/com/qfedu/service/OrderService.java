package com.qfedu.service;

import java.util.List;

import com.qfedu.bean.Order;
import com.qfedu.exception.OrderException;

public interface OrderService {
	//创建订单
	public Order createOrder(int uid,String receiverAddress,String receiverName,String receiverPhone)throws OrderException;
	//支付订单
	public int payOrder(String id)throws OrderException;
	//查询一个用户所有的订单
	public List<Order> findAllByUid(int uid)throws OrderException;
	//查看一个订单
	public Order findOneById(String id)throws OrderException;
	//删除一个订单
	public int delOneById(String id)throws OrderException;
}
