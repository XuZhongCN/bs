package com.qfedu.service.impl;

import java.sql.SQLException;
import java.util.List;

import com.qfedu.bean.Order;
import com.qfedu.dao.OrderDao;
import com.qfedu.dao.impl.OrderDaoImpl;
import com.qfedu.exception.OrderException;
import com.qfedu.service.OrderService;

public class OrderServiceImpl implements OrderService{

	private OrderDao orderDao=new OrderDaoImpl();
	public Order createOrder(int uid, String receiverAddress, String receiverName, String receiverPhone)
			throws OrderException {
		// TODO Auto-generated method stub
		try {
			return orderDao.insertToOrder(uid, receiverAddress, receiverName, receiverPhone);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	public int payOrder(String id) throws OrderException {
		// TODO Auto-generated method stub
		try {
			return orderDao.updatePayState(id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
	public List<Order> findAllByUid(int uid) throws OrderException{
		// TODO Auto-generated method stub
		try {
			return orderDao.selectAllOrderByUid(uid);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public Order findOneById(String id) throws OrderException {
		// TODO Auto-generated method stub
		try {
			return orderDao.selectOneOrderById(id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public int delOneById(String id) throws OrderException {
		// TODO Auto-generated method stub
		try {
			return orderDao.deleteOneOrderById(id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}

}
