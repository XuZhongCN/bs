package com.qfedu.service.impl;

import java.sql.SQLException;

import com.qfedu.bean.ShoppingCar;
import com.qfedu.dao.ShoppingCarDao;
import com.qfedu.dao.impl.ShoppingCarDaoImpl;
import com.qfedu.exception.ShoppingCarException;
import com.qfedu.service.ShoppingCarService;

public class ShoppingCarServiceImpl implements ShoppingCarService{
	private ShoppingCarDao shoppingCarDao=new ShoppingCarDaoImpl();
			
	public int addToCar(int uid, int pid, int count) throws ShoppingCarException {
		// TODO Auto-generated method stub
		
		try {
			return shoppingCarDao.insertToShoppingCarItem(uid, pid, count);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}

	public ShoppingCar showCar(int uid) throws ShoppingCarException {
		// TODO Auto-generated method stub
		
		try {
			return shoppingCarDao.selectShoppingCarByUid(uid);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public int editCar(int uid, int[] pid, int[] count) throws ShoppingCarException {
		// TODO Auto-generated method stub
		try {
			return shoppingCarDao.updateToShoppingCarItem(uid, pid, count);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}

}
