package com.qfedu.service.impl;

import java.sql.SQLException;
import java.util.List;

import com.qfedu.bean.PageBean;
import com.qfedu.bean.Product;
import com.qfedu.dao.ProductDao;
import com.qfedu.dao.impl.ProductDaoImpl;
import com.qfedu.exception.ProductException;
import com.qfedu.service.ProductService;

public class ProductServiceImpl implements ProductService{

	private ProductDao productDao=new ProductDaoImpl();
	public int addProduct(Product product) throws ProductException {
		// TODO Auto-generated method stub
		try {
			return productDao.insertToProduct(product);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
	public List<Product> getProductAll(int pid, String name, String category, double minPrice, double maxPrice)
			throws ProductException {
		// TODO Auto-generated method stub
		try {
			return productDao.selectAll(pid, name, category, minPrice, maxPrice);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public Product findOneById(int pid) throws ProductException {
		// TODO Auto-generated method stub
		try {
			return productDao.selectProductById(pid);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public int editProduct(Product product) throws ProductException {
		// TODO Auto-generated method stub
		try {
			return productDao.updateToProduct(product);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
	public int removeProduct(int pid) throws ProductException {
		// TODO Auto-generated method stub
		
		try {
			return productDao.deleteToProduct(pid);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
	public PageBean findPageBean(int pageNo, String category) throws ProductException {
		// TODO Auto-generated method stub
		try {
			return productDao.selectPageBeanByPage(pageNo, category);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
}
