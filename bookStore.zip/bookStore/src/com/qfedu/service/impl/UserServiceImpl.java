package com.qfedu.service.impl;

import java.sql.SQLException;

import com.qfedu.bean.User;
import com.qfedu.dao.UserDao;
import com.qfedu.dao.impl.UserDaoImpl;
import com.qfedu.exception.UserException;
import com.qfedu.service.UserService;
import com.qfedu.util.MD5Util;

public class UserServiceImpl implements UserService{

	//实例化一个UserDao
	private UserDao userDao=new UserDaoImpl();
	public User regUser(User user) throws UserException {
		// TODO Auto-generated method stub
		try {
			user.setPassword(MD5Util.getMD5(user.getPassword()));
			return userDao.insertToUser(user);
		} catch (SQLException e) {
			//e.getMessage()
			// TODO Auto-generated catch block
			//e.printStackTrace();
			//如果数据库返回的错误代码是UserException.UNI_USERNAME
			//就代表用户名已经存在
			if(e.getErrorCode()==UserException.UNI_USERNAME) {
				UserException userException=new UserException("用户名已经存在。");
				userException.setCode(UserException.UNI_USERNAME);
				throw userException;
			}
			
			
		}
		
		return null;
	}

	public User loginUser(String username, String password) throws UserException {
		// TODO Auto-generated method stub
		try {
			password=MD5Util.getMD5(password);
			return userDao.selectUserByUsernameAndPassword(username, password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public User editUser(User user) throws UserException {
		// TODO Auto-generated method stub
		//在业务逻辑中，“``````”代表密码不变
		try {
		if("``````".equals(user.getPassword())) {
			
			return userDao.updateUser(user.getUid(), user.getGender(), user.getTelephone());
		
		}else {
			//改密码，密码得md5
			user.setPassword(MD5Util.getMD5(user.getPassword()));
			return userDao.updateUser(user.getUid(),user.getPassword(), user.getGender(), user.getTelephone());
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public boolean checkUsername(String username) throws UserException {
		// TODO Auto-generated method stub
		try {
			boolean rs=userDao.selectUserByUsername(username);
			return rs;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

}
