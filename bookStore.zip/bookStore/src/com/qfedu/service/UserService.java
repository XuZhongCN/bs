package com.qfedu.service;

import com.qfedu.bean.User;
import com.qfedu.exception.UserException;

public interface UserService {
	//用户注册
	public User regUser(User user)throws UserException;
	//用户登录
	public User loginUser(String username,String password)throws UserException;
	//用户资料修改
	public User editUser(User user) throws UserException;
	//校验用户名的方法
	public boolean checkUsername(String username)throws UserException;
}
