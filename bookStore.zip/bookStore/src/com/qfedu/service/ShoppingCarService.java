package com.qfedu.service;

import com.qfedu.bean.ShoppingCar;
import com.qfedu.exception.ShoppingCarException;

public interface ShoppingCarService {
	//添加购物车
	public int addToCar(int uid,int pid,int count)throws ShoppingCarException;
	//查看购物车
	public ShoppingCar showCar(int uid)throws ShoppingCarException;
	//编辑购物车
	public int editCar(int uid,int [] pid,int [] count)throws ShoppingCarException;
}
