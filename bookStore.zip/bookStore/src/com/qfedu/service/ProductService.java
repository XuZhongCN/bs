package com.qfedu.service;

import java.sql.SQLException;
import java.util.List;

import com.qfedu.bean.PageBean;
import com.qfedu.bean.Product;
import com.qfedu.exception.ProductException;

public interface ProductService {
	public int addProduct(Product product) throws ProductException;
	public int editProduct(Product product) throws ProductException;
	public int removeProduct(int pid) throws ProductException;
	public List<Product> getProductAll(int pid,String name,String category,double minPrice,double maxPrice)throws ProductException;
	public Product findOneById(int pid) throws ProductException;
	public PageBean findPageBean(int pageNo,String category) throws ProductException;
}
