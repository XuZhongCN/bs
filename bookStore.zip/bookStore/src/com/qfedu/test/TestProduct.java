package com.qfedu.test;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

import com.qfedu.bean.Product;
import com.qfedu.dao.ProductDao;
import com.qfedu.dao.impl.ProductDaoImpl;

public class TestProduct {

	private static ProductDao productDao=new ProductDaoImpl();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Product product=new Product("春联", new BigDecimal(28.82), 100, "文学", "李白写的春联，快来买呀", "asdfasdf");
//		try {
//			int rs=productDao.insertToProduct(product);
//			if(rs>0) {
//				System.out.println("数据插入成功");
//			}
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		try {
			List<Product> list=productDao.selectAll(-1, "2", "", 100, 0);
			System.out.println(list);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
