package com.qfedu.test;

import java.math.BigDecimal;
import java.sql.SQLException;



import com.qfedu.bean.Product;
import com.qfedu.dao.ProductDao;
import com.qfedu.dao.impl.ProductDaoImpl;
import com.qfedu.util.C3P0Util;

public class TestInsertProduct {

	private static ProductDao productDao=new ProductDaoImpl();
	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		for (int i = 0; i < 40; i++) {
			Product product=new Product("《春联"+i+"》", new BigDecimal("28."+i), i, "文学", "这是春联大全"+i, "/upload\\e\\6\\b714b3de-5430-45a9-9f24-88223c36a103_102.jpg");
					
			productDao.insertToProduct(product);
		}
		
	}

}
