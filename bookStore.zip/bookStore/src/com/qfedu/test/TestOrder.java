package com.qfedu.test;

import java.sql.SQLException;

import com.qfedu.bean.Order;
import com.qfedu.dao.OrderDao;
import com.qfedu.dao.impl.OrderDaoImpl;

public class TestOrder {

	private static OrderDao orderDao=new OrderDaoImpl();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Order order=orderDao.insertToOrder(9, "北京市海淀区宝盛广场", "张三", "13236666277");
			if(order!=null) {
				System.out.println("订单生成成功");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
