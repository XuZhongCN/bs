package com.qfedu.test;

import java.sql.SQLException;

import com.qfedu.bean.ShoppingCar;
import com.qfedu.dao.ShoppingCarDao;
import com.qfedu.dao.impl.ShoppingCarDaoImpl;

public class TestShoppingCar {

	private static ShoppingCarDao shoppingCarDao=new ShoppingCarDaoImpl();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//测试添加购物车
		/*try {
			int rs=shoppingCarDao.insertToShoppingCarItem(9, 14, 10);
			if(rs>0) {
				System.out.println("添加购物车成功");
			}else {
				System.out.println("添加购物车失败");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		
		
		//测试查询购物车
		try {
			ShoppingCar shoppingCar=shoppingCarDao.selectShoppingCarByUid(9);
			System.out.println(shoppingCar);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
