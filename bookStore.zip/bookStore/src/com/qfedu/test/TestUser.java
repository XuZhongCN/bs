package com.qfedu.test;

import java.sql.SQLException;

import com.qfedu.bean.User;
import com.qfedu.dao.UserDao;
import com.qfedu.dao.impl.UserDaoImpl;
import com.qfedu.exception.UserException;
import com.qfedu.service.UserService;
import com.qfedu.service.impl.UserServiceImpl;
import com.qfedu.util.MD5Util;

public class TestUser {

	private static  UserDao userDao=new UserDaoImpl();
	private static UserService userService=new UserServiceImpl();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		User user=new User("zhangsan", MD5Util.getMD5("123457"), "男", "123456@qq.com", "13332414006", "第一个用户，测试用户", "001", "baseuser", 1);
		// 测试dao：
		// try {
		// user=userDao.insertToUser(user);
		// System.out.println(user);
		// } catch (SQLException e) {
		// // TODO Auto-generated catch block
		// //当code为1062的时候，就是用户名重复。
		// int code=e.getErrorCode();
		// System.out.println(code);
		// e.printStackTrace();
		// }
		// 测试service:
		try {
			user=userService.regUser(user);
			System.out.println(user);
		} catch (UserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
