package com.qfedu.dao;

import java.sql.SQLException;
import java.util.List;

import com.qfedu.bean.PageBean;
import com.qfedu.bean.Product;

public interface ProductDao {
	//插入一个商品
	public int insertToProduct(Product product)throws SQLException;
	//修改一个商品
	public int updateToProduct(Product product)throws SQLException;
	//删除一个商品
	public int deleteToProduct(int pid)throws SQLException;
	//查询商品的方法
	public List<Product> selectAll(int pid,String name,String category,double minPrice,double maxPrice)throws SQLException;
	//查询一个商品的方法
	public Product selectProductById(int pid) throws SQLException;
	//查询一页数据
	public PageBean selectPageBeanByPage(int pageno,String category)throws SQLException;
}
