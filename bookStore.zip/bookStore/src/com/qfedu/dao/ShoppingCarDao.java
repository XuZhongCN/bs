package com.qfedu.dao;

import java.sql.Connection;
import java.sql.SQLException;

import com.qfedu.bean.ShoppingCar;

public interface ShoppingCarDao {
	//添加购物车
	public int insertToShoppingCarItem(int uid,int pid,int count) throws SQLException;
	//查看购物车
	public ShoppingCar selectShoppingCarByUid(int uid)throws SQLException;
	//保存购物车
	public int updateToShoppingCarItem(int uid,int [] pid,int [] count)throws SQLException;
	//清空购物车
	public int clearShoppingCar(Connection conn,int uid)throws SQLException;
}
