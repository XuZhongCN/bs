package com.qfedu.dao;

import java.sql.SQLException;
import java.util.List;

import com.qfedu.bean.Order;

public interface OrderDao {
	//插入数据到订单表中
	public Order insertToOrder(int uid,String receiverAddress,String receiverName,String receiverPhone)throws SQLException;
	//支付一个订单
	public int updatePayState(String id) throws SQLException;
	//查询订单根据uid
	public List<Order> selectAllOrderByUid(int uid)throws SQLException;
	//查询一个订单
	public Order selectOneOrderById(String id)throws SQLException;
	//删除一个订单
	public int deleteOneOrderById(String id) throws SQLException;
	
}
