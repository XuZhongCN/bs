package com.qfedu.dao.impl;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.qfedu.bean.Order;
import com.qfedu.bean.OrderItem;
import com.qfedu.bean.ShoppingCar;
import com.qfedu.bean.ShoppingCarItem;
import com.qfedu.dao.OrderDao;
import com.qfedu.dao.ShoppingCarDao;
import com.qfedu.util.C3P0Util;

public class OrderDaoImpl implements OrderDao{

	private ShoppingCarDao shoppingCarDao=new ShoppingCarDaoImpl();
	public Order insertToOrder(int uid, String receiverAddress, String receiverName, String receiverPhone)
			throws SQLException {
		// TODO Auto-generated method stub
		//1、要去查购物车
		//2、把购物车中的数据转化为订单数据
		//3、删除掉购物车中的数据
		//4、把转化好的订单数据插入到订单表中，同时还要插入订单条目表。
		//***：上述四个过程是一个事务
		QueryRunner qr=new QueryRunner();
		Connection conn=C3P0Util.getConnection();
		
		
		
		try {
			conn.setAutoCommit(false);
			//1、要去查购物车
			ShoppingCar shoppingCar=shoppingCarDao.selectShoppingCarByUid(uid);
			//2、把购物车中的数据转化为订单数据
			List<ShoppingCarItem> items=shoppingCar.getItems();
			//items->List<OrderItem>
			Order order=new Order();
			//设置订单id
			order.setId(uid+System.currentTimeMillis()+"");
			List<OrderItem> oitems=new ArrayList<OrderItem>();
			BigDecimal money=new BigDecimal("0");
			for(int i=0;i<items.size();i++) {
				//把一个购物车条目转化为一个订单条目
				OrderItem oitem=new OrderItem(items.get(i));
				oitem.setOrderid(order.getId());
				//计算条目小计的总和。
				money=money.add(oitem.getPrice().multiply(new BigDecimal(oitem.getCount())));
				oitems.add(oitem);
				
			}
			//end   ：转化条目结束
			order.setItems(oitems);
			order.setReceiverAddress(receiverAddress);
			order.setReceiverName(receiverName);
			order.setReceiverPhone(receiverPhone);
			order.setMoney(money);
			order.setPaystate(0);
			order.setUid(uid);
			// end :转化结束
			//3、删除掉购物车中的数据
			shoppingCarDao.clearShoppingCar(conn, uid);
			
			
			//4、把转化好的订单数据插入到订单表中，同时还要插入订单条目表。
			String sql="insert into `order`(id,paystate,ordertime,uid,money"
					+ ",receiverAddress,receiverName,receiverPhone) values(?,?,now(),?,?,?,?,?);";
			qr.update(conn,sql,order.getId(),order.getPaystate(),order.getUid(),order.getMoney(),order.getReceiverAddress(),order.getReceiverName(),order.getReceiverPhone());
			sql="insert into orderitem(orderid,pid,`count`) values(?,?,?);";
			for (int i = 0; i < order.getItems().size(); i++) {
				OrderItem item=order.getItems().get(i);
				qr.update(conn,sql,order.getId(),item.getPid(),item.getCount());
			}
			
			conn.commit();
			return order;
		}catch(Exception e) {
			e.printStackTrace();
			conn.rollback();
		}finally {
			if(conn!=null) {
				conn.close();
			}
		}
		return null;
	}
	public int updatePayState(String id) throws SQLException {
		// TODO Auto-generated method stub
		//更新订单的paystate
		QueryRunner qr=new QueryRunner(C3P0Util.getDataSource());
		String sql="update `order` set paystate=1 where id=?";
		return qr.update(sql,id);
	}
	public List<Order> selectAllOrderByUid(int uid) throws SQLException {
		// TODO Auto-generated method stub
		//查看的过程其实不包含List<OrderItem>
		QueryRunner qr=new QueryRunner(C3P0Util.getDataSource());
		String sql="select * from `order` where uid=?";
		List<Order> list=qr.query(sql, new BeanListHandler<Order>(Order.class),uid);
		
		return list;
	}
	public Order selectOneOrderById(String id) throws SQLException {
		// TODO Auto-generated method stub
		QueryRunner qr=new QueryRunner(C3P0Util.getDataSource());
		//Order包含OrderItem，怎么办？
//		id
//		money
//		receiverAddress
//		receiverName
//		receiverPhone
//		paystate
//		ordertime
//		uid

		String sql="select * from `orderitem`,`order`,product where `order`.id=orderitem.orderid and product.pid=`orderitem`.pid and  orderid=?;";
		List<OrderItem> list=qr.query(sql, new BeanListHandler<OrderItem>(OrderItem.class),id);
		sql="select * from `order` where id=?";
		Order order=qr.query(sql, new BeanHandler<Order>(Order.class),id);
		order.setItems(list);
		return order;
	}
	public int deleteOneOrderById(String id) throws SQLException {
		// TODO Auto-generated method stub
		QueryRunner qr=new QueryRunner(C3P0Util.getDataSource());
		String sql="delete from `order` where id=?";
		return qr.update(sql,id);

	}

}
