package com.qfedu.dao.impl;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.qfedu.bean.PageBean;
import com.qfedu.bean.Product;
import com.qfedu.dao.ProductDao;
import com.qfedu.util.C3P0Util;

public class ProductDaoImpl implements ProductDao {

	// private String name;//商品名称
	// private BigDecimal price;//价格
	// private int pnum;//库存数量
	// private String category;//商品类别
	// private String description;//描述
	// private String img_url;//图片的url
	public int insertToProduct(Product product) throws SQLException {
		// TODO Auto-generated method stub
		QueryRunner qr = new QueryRunner(C3P0Util.getDataSource());
		String sql = "insert into product(name,price,pnum,category,description,img_url) values(?,?,?,?,?,?);";
		int rs = qr.update(sql, product.getName(), product.getPrice(), product.getPnum(), product.getCategory(),
				product.getDescription(), product.getImg_url());
		return rs;
	}

	public List<Product> selectAll(int pid, String name, String category, double minPrice, double maxPrice)
			throws SQLException {
		// TODO Auto-generated method stub
		QueryRunner qr = new QueryRunner(C3P0Util.getDataSource());
		String sql = "select * from product where price>=? and price<=? and name like ? and category like ? and pid like ?";
		if (minPrice > maxPrice) {
			double temp = minPrice;
			minPrice = maxPrice;
			maxPrice = temp;
		}
		// 认为如果传入-1，就是pid字段不生效
		String id = "";
		if (pid == -1) {
			id = "";
		} else {
			id = pid + "";
		}
		List<Product> list = qr.query(sql, new BeanListHandler<Product>(Product.class), minPrice, maxPrice,
				"%" + name + "%", "%" + category + "%", "%" + id + "%");

		return list;
	}

	public Product selectProductById(int pid) throws SQLException {
		// TODO Auto-generated method stub
		QueryRunner qr = new QueryRunner(C3P0Util.getDataSource());
		String sql = "select * from product where pid=?";
		Product product = qr.query(sql, new BeanHandler<Product>(Product.class), pid);
		return product;
	}

	public int updateToProduct(Product product) throws SQLException {
		// TODO Auto-generated method stub
		QueryRunner qr=new QueryRunner(C3P0Util.getDataSource());
//		private int pid;//商品id
//		private String name;//商品名称
//		private BigDecimal price;//价格
//		private int pnum;//库存数量
//		private String category;//商品类别
//		private String description;//描述
//		private String img_url;//图片的url
		String sql="update product set name=?,price=?,pnum=?,category=?,description=?,img_url=? where pid=?";
		int rs=qr.update(sql,product.getName(),product.getPrice(),product.getPnum(),product.getCategory(),product.getDescription(),product.getImg_url(),product.getPid());
		
		return rs;
	}

	public int deleteToProduct(int pid) throws SQLException {
		// TODO Auto-generated method stub
		QueryRunner qr=new QueryRunner(C3P0Util.getDataSource());
		String sql="delete from product where pid=?";
		int rs=qr.update(sql,pid);
		
		return rs;
	}

	private static final int pageSize=8; 
	public PageBean selectPageBeanByPage(int pageNo, String category) throws SQLException {
		// TODO Auto-generated method stub
		QueryRunner  qr=new QueryRunner(C3P0Util.getDataSource());
		String sql="select * from product where category like ? limit ?,?";
		List<Product> list=qr.query(sql, new BeanListHandler<Product>(Product.class),"%"+category+"%",(pageNo-1)*pageSize,pageSize);
		PageBean pageBean=new PageBean();
		pageBean.setProducts(list);
		pageBean.setCategory(category);
		pageBean.setPageNo(pageNo);
		pageBean.setPageSize(list.size());
		
		//一共有多少页
		Object object=null;
		object=qr.query("select count(*) from product where category like ?", new ScalarHandler(),"%"+category+"%");
		long pageCount=(Long)object;
		pageBean.setPageCount((int) ((pageCount/pageSize)+((pageCount%pageSize)==0?0:1)));
		//long->int:精度可能损失
		//Long->Integer:ClassCastException
		pageBean.setProductCount((int)pageCount);
		return pageBean;
	}

}
