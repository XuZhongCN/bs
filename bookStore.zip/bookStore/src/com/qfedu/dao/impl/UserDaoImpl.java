package com.qfedu.dao.impl;

import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.qfedu.bean.User;
import com.qfedu.dao.UserDao;
import com.qfedu.util.C3P0Util;

public class UserDaoImpl implements UserDao{

	public User insertToUser(User user) throws SQLException {
		// TODO Auto-generated method stub
		QueryRunner qr=new QueryRunner(C3P0Util.getDataSource());
		String sql="insert into user(username,password,gender,email,telephone,introduce,activeCode"
				+ ",role,state,registTime) values(?,?,?,?,?,?,?,?,?,now());";
		int rs=qr.update(sql,user.getUsername(),user.getPassword(),user.getGender(),user.getEmail()
				,user.getTelephone(),user.getIntroduce(),user.getActiveCode(),user.getRole(),
				user.getState());
		if(rs==1) {
			return selectUserByUsernameAndPassword(user.getUsername(),user.getPassword());
		}else {
			return null;
		}
		
	}

	public User selectUserByUsernameAndPassword(String username, String password) throws SQLException {
		// TODO Auto-generated method stub
		QueryRunner qr=new QueryRunner(C3P0Util.getDataSource());
		String sql="select * from user where username=? and password=?";
		User user=qr.query(sql, new BeanHandler<User>(User.class),username,password);
		return user;
	}

	public User updateUser(User user) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean selectUserByUsername(String username) throws SQLException {
		// TODO Auto-generated method stub
		QueryRunner qr=new QueryRunner(C3P0Util.getDataSource());
		String sql="select count(*) from user where username=?";
		//ScalarHandler而不用BeanHandler，为了节约内存
		Object object=qr.query(sql, new ScalarHandler(),username);
		Long rs=(Long) object;
		if(rs>0) {
			return true;
		}else {
			return false;
		}
		
	}

	public User updateUser(int uid, String password, String gender, String telephone) throws SQLException {
		// TODO Auto-generated method stub
		QueryRunner qr=new QueryRunner(C3P0Util.getDataSource());
		String sql="update user set password=?,gender=?,telephone=? where uid=?";
		int rs=qr.update(sql,password,gender,telephone,uid);
		if(rs>0) {
			return selectUserByUid(uid);
		}
		return null;
	}

	public User updateUser(int uid, String gender, String telephone) throws SQLException {
		// TODO Auto-generated method stub
		
		QueryRunner qr=new QueryRunner(C3P0Util.getDataSource());
		String sql="update user set gender=?,telephone=? where uid=?";
		int rs=qr.update(sql,gender,telephone,uid);
		if(rs>0) {
			return selectUserByUid(uid);
		}
		return null;
	}

	public User selectUserByUid(int uid) throws SQLException {
		// TODO Auto-generated method stub
		QueryRunner qr=new QueryRunner(C3P0Util.getDataSource());
		String sql="select * from user where uid=?";
		User user=qr.query(sql, new BeanHandler<User>(User.class),uid);
		return user;
	}

}
