package com.qfedu.dao.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.qfedu.bean.ShoppingCar;
import com.qfedu.bean.ShoppingCarItem;
import com.qfedu.dao.ShoppingCarDao;
import com.qfedu.util.C3P0Util;

public class ShoppingCarDaoImpl implements ShoppingCarDao{

	public int insertToShoppingCarItem(int uid, int pid, int count) throws SQLException {
		// TODO Auto-generated method stub
		//是insert还是update不好说。
		//判断购物车中有没有pid对应的条目
		//如果有，就更新count字段
		//如果没有，就insert就可以了
		QueryRunner qr=new QueryRunner(C3P0Util.getDataSource());
		String sql="select count(uid) from shoppingcaritem where pid=? and uid=?";
		Object object=qr.query(sql, new ScalarHandler(),pid,uid);
		Long rs=(Long) object;
		int rs1=0;
		if(rs==0) {
			//insert
			sql="insert into shoppingcaritem(uid,pid,`count`) values(?,?,?);";
			rs1=qr.update(sql,uid,pid,count);
		}else {
			//update
			sql="update shoppingcaritem set `count`=`count`+? where pid=? and uid=?";
			rs1=qr.update(sql,count,pid,uid);
		}
		
		return rs1;
	}

	public ShoppingCar selectShoppingCarByUid(int uid) throws SQLException {
		// TODO Auto-generated method stub
		QueryRunner qr=new QueryRunner(C3P0Util.getDataSource());
		String sql="select uid,product.pid as pid,`count`,name,price,category,description,pnum,img_url from shoppingcaritem,product where shoppingcaritem.pid=product.pid and uid=?";
		List<ShoppingCarItem> list=qr.query(sql, new BeanListHandler<ShoppingCarItem>(ShoppingCarItem.class),uid);
		ShoppingCar shoppingCar=new ShoppingCar();
		shoppingCar.setUid(uid);
		shoppingCar.setItems(list);
		
		return shoppingCar;
	}

	public int updateToShoppingCarItem(int uid, int[] pid, int[] count) throws SQLException {
		// TODO Auto-generated method stub
		QueryRunner qr=new QueryRunner();
		Connection conn=C3P0Util.getConnection();
		try {
		//整个过程是一个事务
		conn.setAutoCommit(false);
		//先删除掉原有的内容
		String sql="delete from shoppingcaritem where uid=?;";
		qr.update(conn,sql,uid);
		//新内容添加进来
		sql="insert into shoppingcaritem(uid,pid,`count`) values(?,?,?);";
		for(int i=0;i<pid.length;i++) {
			if(count[i]==0) {
				continue;
			}
			qr.update(conn, sql,uid,pid[i],count[i]);
		}
		
		
		conn.commit();
		return 1;
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			conn.rollback();
		}finally {
			if(conn!=null) {
				conn.close();
			}
		}
		
		
		
		
		return 0;
	}

	public int clearShoppingCar(Connection conn, int uid) throws SQLException {
		// TODO Auto-generated method stub
		
		QueryRunner qr=new QueryRunner();
		String sql="delete from shoppingcaritem where uid=?";
		return qr.update(conn,sql,uid);
	
	}

}
