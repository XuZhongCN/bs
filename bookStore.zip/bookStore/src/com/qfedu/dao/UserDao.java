package com.qfedu.dao;

import java.sql.SQLException;

import com.qfedu.bean.User;

public interface UserDao {
	//插入数据
	//插入成功直接返回插入进去的对象。
	//注册之后直接有登录***
	public User insertToUser(User user)throws SQLException;
	
	//查询数据
	//根据用户名和密码查询一个user，匹配上的user作为返回值，如果没有匹配就返回null
	public User selectUserByUsernameAndPassword(String username,String password)throws SQLException;
	
	
	//修改数据
	//根据传入的user的uid，修改数据库中的表对应的记录。
	//对于用户这种表，我们一般永远不删除。
	//就算用户自己想要删除自己，也是更新语句，让用户的账户失效。
	public User updateUser(User user)throws SQLException;
	public User updateUser(int uid,String password,String gender,String telephone)throws SQLException;
	public User updateUser(int uid,String gender,String telephone)throws SQLException;
	
	//查询一个用户，根据username
	public boolean selectUserByUsername(String username)throws SQLException;
	public User selectUserByUid(int uid)throws SQLException;
}
