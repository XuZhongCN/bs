package com.qfedu.bean;

import java.math.BigDecimal;

//它是购物车中的一个条目
//条目就是一行
public class ShoppingCarItem extends Product{
	//uid和pid这样的形式在数据库中，就是多对多的表述。
	private int uid;
	//private int pid;
	private int count;
	//它是描述pid对应的product，它不存如数据库，它只是为了以后显示购物车的时候方便。
	//private Product product;
	//1   1   1
	//1   5   4
	//牙膏   单价x  个数x  总计
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
//	public int getPid() {
//		return pid;
//	}
//	public void setPid(int pid) {
//		this.pid = pid;
//		this.product.setPid(pid);
//	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
//	public Product getProduct() {
//		return product;
//	}
//	public void setProduct(Product product) {
//		this.product = product;
//	}
//	public String getName() {
//		return this.product.getName();
//	}
//	public void setName(String name) {
//		this.product.setName(name);;
//	}
//	public BigDecimal getPrice() {
//		return product.getPrice();
//	}
//	public void setPrice(BigDecimal price) {
//		this.product.setPrice(price);
//	}
//	public int getPnum() {
//		return this.product.getPnum();
//	}
//	public void setPnum(int pnum) {
//		this.product.setPnum(pnum);
//	}
//	public String getCategory() {
//		return this.product.getCategory();
//	}
//	public void setCategory(String category) {
//		this.product.setCategory(category);
//	}
//	public String getDescription() {
//		return this.product.getDescription();
//	}
//	public void setDescription(String description) {
//		this.product.setDescription(description);
//	}
//	public String getImg_url() {
//		return this.product.getImg_url();
//	}
//	public void setImg_url(String img_url) {
//		this.product.setImg_url(img_url);
//	}

	
}
