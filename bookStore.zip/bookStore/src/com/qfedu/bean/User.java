package com.qfedu.bean;

public class User {
	//用户编号
	private int uid;
	//用户名
	private String username;
	//密码
	private String password;
	//性别
	private String gender;
	//邮箱
	private String email;
	//电话
	private String telephone;
	//简介
	private String introduce;
	//激活码
	private String activeCode;
	//角色***
	private String role;
	//用户状态:0代表未激活、1代表已激活、2代表注销
	private int state;
	//注册时间
	private String registTime;
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getIntroduce() {
		return introduce;
	}
	public void setIntroduce(String introduce) {
		this.introduce = introduce;
	}
	public String getActiveCode() {
		return activeCode;
	}
	public void setActiveCode(String activeCode) {
		this.activeCode = activeCode;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	public String getRegistTime() {
		return registTime;
	}
	public void setRegistTime(String registTime) {
		this.registTime = registTime;
	}
	@Override
	public String toString() {
		return "User [uid=" + uid + ", username=" + username + ", password=" + password + ", gender=" + gender
				+ ", email=" + email + ", telephone=" + telephone + ", introduce=" + introduce + ", activeCode="
				+ activeCode + ", role=" + role + ", state=" + state + ", registTime=" + registTime + "]";
	}
	public User(String username, String password, String gender, String email, String telephone, String introduce,
			String activeCode, String role, int state) {
		super();
		this.username = username;
		this.password = password;
		this.gender = gender;
		this.email = email;
		this.telephone = telephone;
		this.introduce = introduce;
		this.activeCode = activeCode;
		this.role = role;
		this.state = state;
	}
	//它是为了BeanHandler和BeanListHandler
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User(int uid, String password, String gender, String telephone) {
		super();
		this.uid = uid;
		this.password = password;
		this.gender = gender;
		this.telephone = telephone;
	}
	
	
}
