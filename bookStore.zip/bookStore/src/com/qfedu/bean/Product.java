package com.qfedu.bean;

import java.math.BigDecimal;

public class Product {
	private int pid;//商品id
	private String name;//商品名称
	private BigDecimal price;//价格
	private int pnum;//库存数量
	private String category;//商品类别
	private String description;//描述
	private String img_url;//图片的url
	
	public Product(int pid, String name, BigDecimal price, int pnum, String category, String description,
			String img_url) {
		super();
		this.pid = pid;
		this.name = name;
		this.price = price;
		this.pnum = pnum;
		this.category = category;
		this.description = description;
		this.img_url = img_url;
	}
	
	public Product(String name, BigDecimal price, int pnum, String category, String description, String img_url) {
		super();
		this.name = name;
		this.price = price;
		this.pnum = pnum;
		this.category = category;
		this.description = description;
		this.img_url = img_url;
	}

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	public int getPnum() {
		return pnum;
	}
	public void setPnum(int pnum) {
		this.pnum = pnum;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getImg_url() {
		return img_url;
	}
	public void setImg_url(String img_url) {
		this.img_url = img_url;
	}
	@Override
	public String toString() {
		return "Product [pid=" + pid + ", name=" + name + ", price=" + price + ", pnum=" + pnum + ", category="
				+ category + ", description=" + description + ", img_url=" + img_url + "]";
	}
	
	
	
}
