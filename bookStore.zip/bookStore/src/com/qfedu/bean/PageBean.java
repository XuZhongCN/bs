package com.qfedu.bean;

import java.util.List;

public class PageBean<T> {
	private int pageNo;//此页的页码
	private int pageCount;//一共有多少页
	private int pageSize;//这一页有多少数据
	private List<Product> products;//这一页的具体数据
	//private List<T> list;
	private String category;//这一页的类型，“”代表全部商品目录
	private int productCount;//商品总数
	public int getPageNo() {
		return pageNo;
	}
	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}
	public int getPageCount() {
		return pageCount;
	}
	public void setPageCount(int pageCount) {
		this.pageCount = pageCount;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	public List<Product> getProducts() {
		return products;
	}
	public void setProducts(List<Product> products) {
		this.products = products;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public int getProductCount() {
		return productCount;
	}
	public void setProductCount(int productCount) {
		this.productCount = productCount;
	}
	@Override
	public String toString() {
		return "PageBean [pageNo=" + pageNo + ", pageCount=" + pageCount + ", pageSize=" + pageSize + ", products="
				+ products + ", category=" + category + ", productCount=" + productCount + "]";
	}
	public PageBean() {
		super();
	}
	
	
}
