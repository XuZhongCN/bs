package com.qfedu.bean;

//订单的条目
public class OrderItem extends ShoppingCarItem {
	private String orderid;// 这个来描述它属于哪个订单
	// private int pid;//这个条目买的什么商品
	// private int count;//这个商品买了多少个

	public String getOrderid() {
		return orderid;
	}

	public void setOrderid(String orderid) {
		this.orderid = orderid;
	}

	@Override
	public String toString() {
		return "OrderItem [orderid=" + orderid + "]";
	}

	public OrderItem() {
		super();
		// TODO Auto-generated constructor stub
	}
	public OrderItem(ShoppingCarItem item) {
		super();
		this.setCategory(item.getCategory());
		this.setCount(item.getCount());
		this.setDescription(item.getDescription());
		this.setImg_url(item.getImg_url());
		this.setName(item.getName());
		this.setPid(item.getPid());
		this.setPnum(item.getPnum());
		this.setPrice(item.getPrice());
		this.setUid(item.getUid());
	
	}
	
}
