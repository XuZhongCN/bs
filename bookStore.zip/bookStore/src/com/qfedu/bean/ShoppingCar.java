package com.qfedu.bean;

import java.util.List;

public class ShoppingCar {
	//一对一的关系，应该怎么描述？
	private int uid;
	//多对*
	private List<ShoppingCarItem> items;
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public List<ShoppingCarItem> getItems() {
		return items;
	}
	public void setItems(List<ShoppingCarItem> items) {
		this.items = items;
	}
	@Override
	public String toString() {
		return "ShoppingCar [uid=" + uid + ", items=" + items + "]";
	}
	
	
}
