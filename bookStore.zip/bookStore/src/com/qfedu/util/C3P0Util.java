package com.qfedu.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.DataSource;

import com.mchange.v2.c3p0.ComboPooledDataSource;

//其实使用不同的数据库连接池（数据源）
//仅仅是获取dataSource的方式不同，别的都一样。
public class C3P0Util {
	// 连接池对象
	private static DataSource dataSource = new ComboPooledDataSource();
	// 不用写静态块初始化

	//获取连接池的方法
	public static DataSource getDataSource() {
		return dataSource;
	}
	
	// 获取连接的方法
	public static Connection getConnection() {
		try {
			return dataSource.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			throw new RuntimeException("服务器忙。。。");
		}
	}

	// 关闭（归还）资源
	public static void release(ResultSet rs, Statement ps, Connection conn) {
		try {
			if (rs != null) {
				rs.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			if (ps != null) {
				ps.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			if (conn != null) {
				// 确实看上去是关闭，但其实用装饰者设计模式修改了close的功能
				// 功能已经是还回去的意思.
				conn.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
