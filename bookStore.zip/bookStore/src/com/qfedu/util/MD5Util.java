package com.qfedu.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class MD5Util {
	private static final char[] hexDigits= {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};

	public static String getMD5(String inStr) {
		byte[] inStrBytes=inStr.getBytes();
		
		try {
			MessageDigest md5=MessageDigest.getInstance("MD5");
			md5.update(inStrBytes);
			//取出运算结果
			byte [] mdByte=md5.digest();
			char [] str=new char[mdByte.length*2];
			//定义一个角标
			int k=0;
			for(int i=0;i<mdByte.length;i++) {
				byte temp=mdByte[i];
				//高四位
				//0110 1001
				//0000 0110
				//0000 1111
				//0000 0110
				str[k++]=hexDigits[temp>>>4&0xf];
				//低四位
				str[k++]=hexDigits[temp&0xf];
				
			}
			return new String(str);
			
			
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

}
