package com.qfedu.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;

import com.qfedu.bean.User;

/**
 * Servlet Filter implementation class RoleFilter
 */
//此过滤器为权限控制过滤器
//我们的web应用面向不同用户有不同权限。
@WebFilter("/admin/*")
public class RoleFilter implements Filter {

    /**
     * Default constructor. 
     */
    public RoleFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here
		
		// pass the request along the filter chain
		HttpServletRequest httpRequest=(HttpServletRequest)request;
		User user=(User) httpRequest.getSession().getAttribute("user");
		//如果user是null或者user的身份不是admin，都不可以放行。
		if(user==null||!"admin".equals(user.getRole())) {
			httpRequest.setAttribute("errorMessage", "对不起，您无权访问此页面");
			httpRequest.setAttribute("errorPage", httpRequest.getContextPath()+"/index.jsp");
			httpRequest.getRequestDispatcher("/error.jsp").forward(request, response);
			return ;
		}
		chain.doFilter(request, response);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
