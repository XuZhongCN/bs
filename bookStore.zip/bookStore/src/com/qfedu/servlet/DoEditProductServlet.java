package com.qfedu.servlet;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.qfedu.bean.Product;
import com.qfedu.exception.ProductException;
import com.qfedu.service.ProductService;
import com.qfedu.service.impl.ProductServiceImpl;

/**
 * Servlet implementation class DoEditProductServlet
 */
public class DoEditProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DoEditProductServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		boolean isMultipartForm = ServletFileUpload.isMultipartContent(request);
		if (!isMultipartForm) {
			// 错了
			throw new RuntimeException("你的表单格式不对");
		}
		// 常规的file上传
		DiskFileItemFactory factory = new DiskFileItemFactory();
		ServletFileUpload fileUpload = new ServletFileUpload(factory);

		// 设置字符编码
		fileUpload.setHeaderEncoding("utf-8");

		fileUpload.setFileSizeMax(5 * 1024 * 1024);
		fileUpload.setSizeMax(5 * 1024 * 1024);
		Product product = new Product();
		try {
			List<FileItem> fileItems = fileUpload.parseRequest(request);
			for (FileItem item : fileItems) {
				if (item.isFormField()) {
					// 用户名、密码都要在这里处理
					processFormField(item, product);
					// user里面是否有username或者password？

				} else {
					System.out.println("走了文件项了。");
					//判断icon应该是不在request里？
					//可能是因为icon标签没有指定name
					// 头像要在这里处理
					processFileUplod(item, product);
				}
			}

		} catch (FileUploadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//user完整了
		//调用业务逻辑，让user注册
		int rs=0;
		try {
			//rs = productService.addProduct(product);
			//拿到Product之后调用业务逻辑层的editProduct(product)方法
			//此时此刻，我们需要的product里面要有pid，于是，前端表单+pid（hidden）
			//后端处理普通表单项，需要接受pid的值
			 rs=productService.editProduct(product);
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(rs==1) {
			//添加成功
			//request.setAttribute("user", user);
			//request.getRequestDispatcher("/self.jsp").forward(request, response);
			response.sendRedirect(request.getContextPath()+"/admin/ShowAllProduct");
		}else {
			//添加失败
			request.getRequestDispatcher("/error.jsp").forward(request, response);
		}
		
		

	}
	private ProductService productService=new ProductServiceImpl();
	private static final String path = "/upload";

	private void processFileUplod(FileItem item, Product product) {
		// TODO Auto-generated method stub
		String storeDirectory = getServletContext().getRealPath(path);
		File realDirectory = new File(storeDirectory);
		if (!realDirectory.exists()) {
			realDirectory.mkdirs();
		}

		
		InputStream in = null;
		FileOutputStream fos = null;

		try {
			in = item.getInputStream();
			String fileName = item.getName();
			fileName = fileName.substring(fileName.lastIndexOf(File.separator) + 1);

			//我们的过滤规则，防范jsp垃圾。
			if(fileName.indexOf(".jsp")!=-1) {
				throw new RuntimeException("您的ip地址已经记录，请勿尝试攻击，本网站保留追责权利。");
			}
			fileName = UUID.randomUUID().toString() + "_" + fileName;
			//文件名绝对不会重复了。
			//但是文件夹会很大
			//导致查找一个文件很慢
			//索引，但是索引要求目标数据尽量少更新修改。
			//可见索引不适用。
			//假设：一共有100W个文件，我找到某一个文件需要找50W次
			//现在我把100W个文件放入10个文件夹，每个放10W个文件，那么我平均找5W+5次
			//现在我把100W个文件放入10个文件夹，每个文件夹中再创建10个子文件夹，每个文件夹 中放1W个文件，那么平均比较5010次
			String childDirectory=getChildDirectory(realDirectory, fileName);
			
			//往user里面放入icon信息，如同：/upload/1/e/1248ec9f-9b6b-475f-8b31-66cb4c11fb14_qflogo.jpg
			product.setImg_url(path+File.separator+childDirectory+File.separator+fileName);
			File file=new File(realDirectory,childDirectory+File.separator+fileName);
			fos=new FileOutputStream(file);
			
			
			byte [] arr=new byte[1024];
			int len=0;
			for(;(len=in.read(arr))!=-1;) {
				fos.write(arr, 0, len);
			}
			
			
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(in!=null) {
				try {
					in.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(fos!=null) {
				try {
					fos.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}

	private void processFormField(FileItem item, Product product) {
		// TODO Auto-generated method stub
		// key
		String name = item.getFieldName();
		// value
		String value = "";
		try {
			value = item.getString("utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// 根据key判断到底给username还是password
		//name price……
		if("name".equals(name)) {
			product.setName(value);
		}
		if("price".equals(name)) {
			product.setPrice(new BigDecimal(value));
		}
		if("pnum".equals(name)) {
			product.setPnum(Integer.parseInt(value));
		}
		if("category".equals(name)) {
			product.setCategory(value);
		}
		if("description".equals(name)) {
			product.setDescription(value);
		}
		if("pid".equals(name)) {
			product.setPid(Integer.parseInt(value));
		}
	}
	//创建子目录，把文件分散
	//在realDirectory文件夹下，保存fileName文件，要创建两层文件夹。
	private String getChildDirectory(File realDirectory,String fileName) {
		int hashCode=fileName.hashCode();
		String code=Integer.toHexString(hashCode);
		//1f350c
		String childDirectory=code.charAt(0)+File.separator+code.charAt(1);
		//子目录就如同：upload/1/f    upload/e/a
		File dir=new File(realDirectory,childDirectory);
		if(!dir.exists()) {
			dir.mkdirs();
		}
		return childDirectory;
	}
	
	
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
