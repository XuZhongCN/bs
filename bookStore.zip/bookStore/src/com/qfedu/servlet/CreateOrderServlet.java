package com.qfedu.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qfedu.bean.Order;
import com.qfedu.bean.User;
import com.qfedu.dao.OrderDao;
import com.qfedu.exception.OrderException;
import com.qfedu.service.OrderService;
import com.qfedu.service.impl.OrderServiceImpl;

/**
 * Servlet implementation class CreateOrderServlet
 */
public class CreateOrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateOrderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    private OrderService orderService=new OrderServiceImpl();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		User user=(User) request.getSession().getAttribute("user");
		if(user==null) {
			//跳转到登录页面
			//用户名或者密码错误。
			request.setAttribute("login_message", "您还未登录。");
			request.getRequestDispatcher("/login.jsp").forward(request, response);
			return ;
		}
		String receiverAddress=request.getParameter("receiverAddress");
		String receiverName=request.getParameter("receiverName");
		String receiverPhone=request.getParameter("receiverPhone");
		int uid=user.getUid();
		
		try {
			Order order=orderService.createOrder(uid, receiverAddress, receiverName, receiverPhone);
			if(order!=null) {
				//成功
				//把订单显示给用户看
				request.setAttribute("order", order);
				request.getRequestDispatcher("/orderInfo.jsp").forward(request, response);
			}
		} catch (OrderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
