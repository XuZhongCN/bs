package com.qfedu.servlet;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ImageCode
 */
public class ImageCode extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ImageCode() {
		super();
		// TODO Auto-generated constructor stub
	}

	// 所有的请求都对应一个words
	private List<String> words = new ArrayList<String>();

	// init方法什么时候执行？
	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
		// 初始化words
		String path = getServletContext().getRealPath("/WEB-INF/new_words.txt");
		BufferedReader reader = null;

		try {
			// reader就是读取new_words.txt的读取对象
			reader = new BufferedReader(new InputStreamReader(new FileInputStream(path), "utf-8"));
			String line;
			for (; (line = reader.readLine()) != null;) {
				words.add(line);
			}

		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (reader != null) {
					reader.close();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	//验证码4.0-final
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		Random random=new Random();
		
		String word=words.get(random.nextInt(words.size()));
		//把word变成图片。
		//把要画的验证码放入session中，为了之后前端校验使用
		request.getSession().setAttribute("checkcode_session", word);
		
		
		//开始绘制
		//定义尺寸
		int width=120;
		int height=30;
		
		//生成一个图片
		BufferedImage bufferedImage=new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		//获取绘制对象
		Graphics graphics=bufferedImage.getGraphics();
		
		//使得背景色比较浅
		Color color=getRandomColor(200, 255);
		
		
		//绘制背景
		graphics.setColor(color);
		graphics.fillRect(0, 0, width, height);
		
		//绘制边框
		graphics.setColor(Color.WHITE);
		graphics.drawRect(0, 0, width-1, height-1);
		
		
		//绘制验证码
		Graphics2D graphics2d=(Graphics2D)graphics;
		//设置字体
		graphics2d.setFont(new Font("宋体",Font.BOLD,18));
		//定义一个横坐标
		int x=10;
		
		for (int i = 0; i < word.length(); i++) {
			//使得汉字的颜色比较深
			graphics2d.setColor(getRandomColor(20, 110));
			//设置旋转的角度
			int angle=random.nextInt(60)-30;
			//一定要把它换算成弧度制
			double theta=Math.PI/180*angle;
			//这一次要绘制的汉字
			char c=word.charAt(i);
			
			//画文字
			graphics2d.rotate(theta, x, 20);
			graphics2d.drawString(c+"", x, 20);
			graphics2d.rotate(-theta, x, 20);
			x+=30;
			
			
		}
		
		
		//绘制噪点
		//颜色160~200
		graphics.setColor(getRandomColor(160, 200));
		int x1;
		int x2;
		int y1;
		int y2;
		for (int i = 0; i < 30; i++) {
			x1=random.nextInt(width);
			y1=random.nextInt(height);
			x2=x1+random.nextInt(12);
			y2=y1+random.nextInt(12);
			graphics.drawLine(x1, y1, x2, y2);
		}
		
		
		
		
		
		//释放资源
		graphics.dispose();
		ImageIO.write(bufferedImage, "jpg", response.getOutputStream());
		
		
		
	}
	//fc=200  ec=255
	//r、g、b三者都在200~255之间，而且还不相等，所以，只是它的颜色比较浅而已。
	private Color getRandomColor(int fc,int ec) {
		//获取fc~ec之前的随机的颜色
		Random random=new Random();
		int r=fc+random.nextInt(ec-fc);
		int g=fc+random.nextInt(ec-fc);
		int b=fc+random.nextInt(ec-fc);
		return new Color(r,g,b);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
