package com.qfedu.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qfedu.bean.User;
import com.qfedu.exception.OrderException;
import com.qfedu.service.OrderService;
import com.qfedu.service.impl.OrderServiceImpl;

/**
 * Servlet implementation class DeleteOneOrderServlet
 */
public class DeleteOneOrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteOneOrderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    private OrderService orderService=new OrderServiceImpl();
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//删除掉传入的id对应的order
		String id=request.getParameter("id");
		try {
			int rs=orderService.delOneById(id);
			//展示所有的order->ShowAllOrderServlet
			if(rs>0) {
			
				request.getRequestDispatcher("/ShowAllOrderServlet").forward(request, response);
			}
		} catch (OrderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
