package com.qfedu.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qfedu.bean.User;
import com.qfedu.exception.UserException;
import com.qfedu.service.UserService;
import com.qfedu.service.impl.UserServiceImpl;

/**
 * Servlet implementation class RegisterServlet
 */
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("注册功能不支持该请求，请勿尝试破解。");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	private UserService userService=new UserServiceImpl();
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//RegisterServlet拿到值
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		String email=request.getParameter("email");
		String gender=request.getParameter("gender");
		String introduce=request.getParameter("introduce");
		String telephone=request.getParameter("telephone");
		//放入数据库
		//首先要有一个User
		User user=new User(username, password, gender, email, telephone, introduce, "", "baseuser", 1);
		
		try {
			user=userService.regUser(user);
		} catch (UserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			if(e.getCode()==UserException.UNI_USERNAME) {
				//应该给用户报错
				request.setAttribute("errorMessage", e.getMessage());
				request.setAttribute("errorPage", "register.jsp");
				request.getRequestDispatcher("/error.jsp").forward(request, response);;
			}
		}
		
	}

}
