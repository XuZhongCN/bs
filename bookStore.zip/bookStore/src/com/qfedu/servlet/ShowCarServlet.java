package com.qfedu.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qfedu.bean.ShoppingCar;
import com.qfedu.bean.User;
import com.qfedu.exception.ShoppingCarException;
import com.qfedu.service.ShoppingCarService;
import com.qfedu.service.impl.ShoppingCarServiceImpl;

/**
 * Servlet implementation class ShowCarServlet
 */
public class ShowCarServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowCarServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    private ShoppingCarService shoppingCarService=new ShoppingCarServiceImpl();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//uid
		User user=(User) request.getSession().getAttribute("user");
		if(user==null) {
			//跳转到登录页面
			//用户名或者密码错误。
			request.setAttribute("login_message", "您还未登录。");
			request.getRequestDispatcher("/login.jsp").forward(request, response);
			return ;
		}
		int uid=user.getUid();
		try {
			ShoppingCar shoppingCar=shoppingCarService.showCar(uid);
			//把购物车添加到request中然后跳转
			request.setAttribute("car", shoppingCar);
			request.getRequestDispatcher("cart.jsp").forward(request, response);
		} catch (ShoppingCarException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
