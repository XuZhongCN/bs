package com.qfedu.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qfedu.bean.User;
import com.qfedu.exception.ShoppingCarException;
import com.qfedu.service.ShoppingCarService;
import com.qfedu.service.impl.ShoppingCarServiceImpl;

/**
 * Servlet implementation class JiXuServlet
 */
public class JiXuServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public JiXuServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    private ShoppingCarService shoppingCarService=new ShoppingCarServiceImpl();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		User user=(User) request.getSession().getAttribute("user");
		if(user==null) {
			//跳转到登录页面
			//用户名或者密码错误。
			request.setAttribute("login_message", "您还未登录。");
			request.getRequestDispatcher("/login.jsp").forward(request, response);
			return ;
		}
		
		
		String [] strPid=request.getParameterValues("pid");
		String [] strCount=request.getParameterValues("count");
		int [] pid=new int[strPid.length];
		int [] count=new int [strCount.length];
		//转化过程
		for (int i = 0; i < count.length; i++) {
			pid[i]=Integer.parseInt(strPid[i]);
			count[i]=Integer.parseInt(strCount[i]);
		}
		
		
		
		
		int uid=user.getUid();
		
		try {
			int rs=shoppingCarService.editCar(uid, pid, count);
			if(rs>0) {
				//成功
				request.getRequestDispatcher("/ShowProductPageByCategory?category=").forward(request, response);
			}
		} catch (ShoppingCarException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
