package com.qfedu.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qfedu.bean.ShoppingCar;
import com.qfedu.bean.User;
import com.qfedu.exception.ShoppingCarException;
import com.qfedu.service.ShoppingCarService;
import com.qfedu.service.impl.ShoppingCarServiceImpl;

/**
 * Servlet implementation class AddToCarServlet
 */
public class AddToCarServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddToCarServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    private ShoppingCarService shoppingCarService=new ShoppingCarServiceImpl();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//我们要调用shoppingcarservice的添加购物车
		//因此需要uid，pid，count
		//uid在session里，如果不在，就让用户登录
		//pid，count应该给我传过来
		
		User user=(User) request.getSession().getAttribute("user");
		if(user==null) {
			//跳转到登录页面
			//用户名或者密码错误。
			request.setAttribute("login_message", "您还未登录。");
			request.getRequestDispatcher("/login.jsp").forward(request, response);
			return ;
		}
		String strPid=request.getParameter("pid");
		String strCount=request.getParameter("count");
		int pid=Integer.parseInt(strPid);
		int count=Integer.parseInt(strCount);
		int uid=user.getUid();
		try {
			int rs=shoppingCarService.addToCar(uid, pid, count);
			if(rs>0) {
				//添加成功
				//你要在购物车上显示出你的购物车中所有的商品，怎么办？
				//需要查询购物车
				ShoppingCar shoppingCar=shoppingCarService.showCar(uid);
				//把购物车添加到request中然后跳转
				request.setAttribute("car", shoppingCar);
				request.getRequestDispatcher("cart.jsp").forward(request, response);
			}
		} catch (ShoppingCarException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
