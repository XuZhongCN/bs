package com.qfedu.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qfedu.bean.Product;
import com.qfedu.exception.ProductException;
import com.qfedu.service.ProductService;
import com.qfedu.service.impl.ProductServiceImpl;

/**
 * Servlet implementation class ShowAllProduct
 */
public class ShowAllProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowAllProduct() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    private ProductService productService=new ProductServiceImpl();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String strPid=request.getParameter("pid");
		int pid=-1;
		if(strPid!=null&&!"".equals(strPid)) {
		pid=Integer.parseInt(strPid);
		}
		//name->null而不是“”
		String name=request.getParameter("name");
		if(name==null) {
			name="";
		}
		
		String category=request.getParameter("category");
		if(category==null) {
			category="";
		}
		String strminPrice=request.getParameter("minPrice");
		String strmaxPrice=request.getParameter("maxPrice");
		double minPrice=0;
		double maxPrice=999999.99;
		
		//strminPrice==null
		if(strminPrice!=null&&!"".equals(strminPrice)) {
			minPrice=Double.parseDouble(strminPrice);
		}
		
		if(strmaxPrice!=null&&!"".equals(strmaxPrice)) {
			maxPrice=Double.parseDouble(strmaxPrice);
		}
		try {
			List<Product> products=productService.getProductAll(pid, name, category, minPrice, maxPrice);
			//System.out.println(products);
			//把查询出来的结果list放到request共享域里。
			request.setAttribute("products", products);
			
			//跳到哪里去？/admin/products/list.jsp
			request.getRequestDispatcher("/admin/products/list.jsp").forward(request, response);
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
