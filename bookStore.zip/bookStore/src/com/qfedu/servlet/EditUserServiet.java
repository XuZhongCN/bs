package com.qfedu.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qfedu.bean.User;
import com.qfedu.exception.UserException;
import com.qfedu.service.UserService;
import com.qfedu.service.impl.UserServiceImpl;

/**
 * Servlet implementation class EditUserServiet
 */
public class EditUserServiet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditUserServiet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	private UserService userService=new UserServiceImpl();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//modifyUserInfoSuccess.jsp
		
		String uid=request.getParameter("uid");
		String password=request.getParameter("password");
		String gender=request.getParameter("gender");
		String telephone=request.getParameter("telephone");
		
		User user=new User(Integer.parseInt(uid), password, gender, telephone);
		try {
			user =userService.editUser(user);
			request.getSession().setAttribute("user", user);
			request.getRequestDispatcher("/modifyUserInfoSuccess.jsp").forward(request, response);
		} catch (UserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}

}
