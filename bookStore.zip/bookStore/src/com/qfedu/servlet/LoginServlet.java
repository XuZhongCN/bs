package com.qfedu.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qfedu.bean.User;
import com.qfedu.exception.UserException;
import com.qfedu.service.UserService;
import com.qfedu.service.impl.UserServiceImpl;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	private UserService userService=new UserServiceImpl();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		//登录逻辑
		try {
			User user=userService.loginUser(username, password);
			if(user!=null) {
				//我们把user放入session中，作为这一次会话登录的过的凭证。
				request.getSession().setAttribute("user", user);
				//根据user中的身份不同，要跳转到不同的页面
				if(!"admin".equals(user.getRole())) {
					//sendRedirect
					//getRequestDispatcher
					//上面两个方法，前者是重定向
					//后者是转发
					//当我把数据放入request中的时候
					//如果使用前者，将会在页面拿不到值。
					//因为重定向其实是产生了另一个request
					//而转发是由始至终只有一个request
					request.getRequestDispatcher("/ShowProductPageByCategory?category=").forward(request, response);
					
				}else 
				{
					request.getRequestDispatcher("/admin/login/home.jsp").forward(request, response);
				}
			}else {
				//用户名或者密码错误。
				request.setAttribute("login_message", "用户名/密码错误。");
				request.getRequestDispatcher("/login.jsp").forward(request, response);
			}
		} catch (UserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
