package com.qfedu.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qfedu.bean.Order;
import com.qfedu.bean.User;
import com.qfedu.exception.OrderException;
import com.qfedu.service.OrderService;
import com.qfedu.service.impl.OrderServiceImpl;

/**
 * Servlet implementation class ShowAllOrderServlet
 */
public class ShowAllOrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowAllOrderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    private OrderService orderService=new OrderServiceImpl();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//展示一个用户所有的订单
		User user=(User) request.getSession().getAttribute("user");
		if(user==null) {
			//跳转到登录页面
			//用户名或者密码错误。
			request.setAttribute("login_message", "您还未登录。");
			request.getRequestDispatcher("/login.jsp").forward(request, response);
			return ;
		}
		int uid=user.getUid();
		List<Order> orders=null;
		try {
			orders = orderService.findAllByUid(uid);
			request.setAttribute("orders", orders);
			request.getRequestDispatcher("/orderlist.jsp").forward(request, response);
		} catch (OrderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
