package com.qfedu.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qfedu.exception.ProductException;
import com.qfedu.service.ProductService;
import com.qfedu.service.impl.ProductServiceImpl;

/**
 * Servlet implementation class DelProductServlet
 */
public class DelProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DelProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    private ProductService productService=new ProductServiceImpl();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//获取pid
		String strPid=request.getParameter("pid");
		int pid=Integer.parseInt(strPid);
		//调用service
		try {
			int rs=productService.removeProduct(pid);
			//跳转页面
			if(rs>0) {
				//跳转到哪里？
				//list.jsp
				//ShowAllProduct->list.jsp
				//重定向list.jsp***
				
				//request.getRequestDispatcher("/admin/ShowAllProduct").forward(request, response);
				//重定向到/admin/ShowAllProduct
				response.sendRedirect(request.getContextPath()+"/admin/ShowAllProduct");
			}
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
